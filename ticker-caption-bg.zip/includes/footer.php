			<footer style="    position: fixed;left: 0;right: 0; bottom: 0;" class="footer">
				<div class="container-fluid">
					<nav class="pull-left">
						<ul class="nav">
						    <li class="nav-item">
								<a class="nav-link" href="tel:">
									Contact US
								</a>
							</li>
							<li class="nav-item">
								<a class="nav-link" href="/help">
									Customer Support
								</a>
							</li>
							<li class="nav-item">
								<a class="nav-link" href='/admin/'>
									Admin
								</a>
							</li>
						</ul>
					</nav>
					<div class="copyright ml-auto">
						Car Wash Nextgen &copy; <?php echo Date("Y"); ?>
					</div>				
				</div>
			</footer>