<!DOCTYPE html>
<html lang="en">
    <?php include 'includes/head.php';?>
    <?php include 'url.php';?>
<body id="body">
	<div class="wrapper">
		<div class="main-panel2">
			<div class="content">
				<div class="page-inner">
				    <div class="card ticker-container bubble-shadow-small" id="new_ticker">
                    </div>
					<div class="row"  id="dashboard">
					</div>
				</div>
			</div>
		</div>
	</div>
    <?php include 'includes/scripts.php';?>
</body>
</html>