			<footer class="footer">
				<div class="container-fluid">
					<div class="row text-muted">
						<div class="col-6 text-left">
							<p class="mb-0">
								Devloped by <a href="https://www.nextgensoft.co.ke" class="text-muted"><strong>Nextgensoft.</strong></a> &copy; <?php echo date("Y");?> | <a href="https://www.nextgensoft.co.ke" class="text-muted"><strong>nextgensoft.co.ke</strong></a>
							</p>
						</div>
						<div class="col-6 text-right">
							<ul class="list-inline">
								<li class="list-inline-item">
									<a class="text-muted" href="https://www.nextgensoft.co.ke">Developer Support</a>
								</li>
								<li class="list-inline-item">
									<a class="text-muted" href="mailto:developer@nextgensoft.co.ke">Help Center</a>
								</li>
							</ul>
						</div>
					</div>
				</div>
			</footer>